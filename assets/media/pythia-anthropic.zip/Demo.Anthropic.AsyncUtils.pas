unit Demo.Anthropic.AsyncUtils;

interface

uses
  System.SysUtils, System.IOUtils,
  Anthropic, Anthropic.Types, Anthropic.Helpers,
  WVPythia.Chat.Interfaces, WVPythia.Vendors.Services;

type
  IAnthropicClientUtils = interface
    ['{7A5E70A4-251C-47B0-BBBA-185DA65A2A76}']
    procedure AsyncFetchFile(const ID: string; const Filename: string);
    procedure SessionRename(ChatID, ContentToSummarize: string);
  end;

  TAnthropicClientUtils = class(TInterfacedObject, IAnthropicClientUtils)
  private
    FClient: IAnthropic;
    FPythia: IPythiaBrowser;
    procedure SessionRename(ChatID, ContentToSummarize: string);
  public
    constructor Create(const AClient: IAnthropic; const ABrowser: IPythiaBrowser);

    procedure AsyncFetchFile(const ID: string; const Filename: string);
    procedure ASyncSessionRename(const ChatID: string; const ContentToSummarize: string);
  end;

implementation

{ TAnthropicClientUtils }

procedure TAnthropicClientUtils.AsyncFetchFile(const ID, Filename: string);
begin
  var Promise := FClient.Files.AsyncAwaitDownload(ID);

  Promise
    .&Then(
      procedure (Value: TFileDownloaded)
      begin
        Value.SaveToFile(FileName);
      end)
    .&Catch(
      procedure (E: Exception)
      begin
        if Assigned(FPythia) then
          FPythia.DisplayError(Format('File not found:#10%s', [Filename]))
      end);
end;

procedure TAnthropicClientUtils.ASyncSessionRename(const ChatID,
  ContentToSummarize: string);
begin
  var Model := 'claude-haiku-4-5';
  var MaxTokens := 1000;
  var SystemPrompt :=
    '# Rules :' + slineBreak +
    '- Do not comment on your answer' + slineBreak +
    '- Display only the answer' + slineBreak +
    '- Do not use articles or pronouns' + slineBreak +
    '- Write at most 7 words';
  var Prompt := Format('Summarize the following message:'#10'%s', [ContentToSummarize]);

  var Payload: TChatParamProc :=
    procedure (Params: TChatParams)
    begin
      Params
        .Model(Model)
        .System(SystemPrompt)
        .Messages( Generation.MessageParts
          .User(Prompt)
        )
        .MaxTokens(MaxTokens);
    end;

  var Promise := FClient.Chat.AsyncAwaitCreate(Payload);

  Promise
    .&Then(
      procedure (Value: TChat)
      begin
        var Name := '';

        for var Content in Value.Content do
          begin
            if Content.&Type = TContentBlockType.text then
              Name := Content.Text;
          end;

        if Name.IsEmpty then
          Exit;

        if not Assigned(FPythia)  then
          Exit;

        if not Assigned(FPythia.PersistentChat) then
          Exit;

        FPythia.PersistentChat.UpdateChatTitleById(ChatID, Name);
        FPythia.ChatSessionRename(ChatID, Name);
      end)
    .&Catch(
      procedure (E: Exception)
      begin
        {--- Silent error }
      end);
end;

constructor TAnthropicClientUtils.Create(const AClient: IAnthropic;
  const ABrowser: IPythiaBrowser);
begin
  inherited Create;
  FClient := AClient;
  FPythia := ABrowser;
end;

procedure TAnthropicClientUtils.SessionRename(ChatID,
  ContentToSummarize: string);
begin
  ASyncSessionRename(ChatID, ContentToSummarize);
end;

end.
