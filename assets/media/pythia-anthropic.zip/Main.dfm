object Form1: TForm1
  Left = 0
  Top = 0
  AlphaBlend = True
  AlphaBlendValue = 0
  Caption = 'Pythia-Webview2 - Anthropic vendor Demo'
  ClientHeight = 653
  ClientWidth = 1079
  Color = clWindow
  Ctl3D = False
  DoubleBuffered = True
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  OnCloseQuery = FormCloseQuery
  OnCreate = FormCreate
  TextHeight = 15
  object Panel2: TPanel
    Left = 0
    Top = 0
    Width = 1079
    Height = 653
    Align = alClient
    BevelOuter = bvNone
    Caption = 'Panel2'
    ParentBackground = False
    ShowCaption = False
    TabOrder = 0
  end
end
